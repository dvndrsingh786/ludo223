//----------------------------------------------
// LitJson Ruler
// © 2015 yedo-factory
// Version 1.0.0
//----------------------------------------------
LitJson Ruler is Asset which automated all exchange of communication using LitJson in Excel!

1.Communication interface create in Excel
2.On Unity, Excel data, parse (only 1 button)
3.You communicate in the auto-generated class (only 1 code!)

That's all.

A renewal can introduce everyone easily and is also easy. It's Excel, so the exchange of communication is also easy to understand.
LitJson Ruler also creates all classes automatically communication data of the complicated structure.

The LitJson life comfortable in LitJson Ruler...!

■How to use
(1)Project[LJR/Editor/HttpInterface.xls] communication interface is described
(2)Menu[Tools/LJR/Create] communication class create
(3)Project[LJR/Scripts/Http/***] communication class is set in Hierarchy and execute Send method. The communication on UnityEditor is also possible from a Inspector [test] Button. Communication data is shown to Inspector, so when it's confirmation by a [Test] button, communication can be even performed by No coding!
※Please change [HttpInterface.xls/Setting/BaseURL] to an operations check of Demo communication in your environment.

■Version History
1.0.0
- First release